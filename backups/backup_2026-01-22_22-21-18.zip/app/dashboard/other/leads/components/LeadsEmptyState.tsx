"use client"

import { motion } from "framer-motion"
import { PlusIcon, UserGroupIcon } from "@heroicons/react/24/outline"

interface LeadsEmptyStateProps {
  onCreateLead: () => void
}

export function LeadsEmptyState({ onCreateLead }: LeadsEmptyStateProps) {
  return (
    <motion.div
      className="text-center py-16 bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-2xl"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        className="mb-6"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, duration: 0.5, type: "spring" }}
      >
        <div className="w-20 h-20 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <UserGroupIcon className="w-10 h-10 text-purple-400" />
        </div>
      </motion.div>

      <motion.h3
        className="text-xl font-semibold text-white mb-2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        No hay leads registrados
      </motion.h3>

      <motion.p
        className="text-gray-400 mb-8 max-w-md mx-auto"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
      >
        Comienza a construir tu pipeline de ventas añadiendo tu primer lead.
        Importa contactos o crea uno manualmente.
      </motion.p>

      <motion.button
        onClick={onCreateLead}
        className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg hover:shadow-purple-500/25"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        whileHover={{ scale: 1.05, y: -2 }}
        whileTap={{ scale: 0.95 }}
      >
        <PlusIcon className="w-5 h-5" />
        Crear primer lead
      </motion.button>
    </motion.div>
  )
}