"use client"

import { motion } from "framer-motion"
import { LeadItem } from "./mock"
import {
  FireIcon,
  SunIcon,
  SparklesIcon,
  CurrencyEuroIcon
} from "@heroicons/react/24/outline"

interface LeadsKPIsProps {
  leads: LeadItem[]
}

export function LeadsKPIs({ leads }: LeadsKPIsProps) {
  const hotLeads = leads.filter(lead => lead.status === 'hot').length
  const warmLeads = leads.filter(lead => lead.status === 'warm').length
  const coldLeads = leads.filter(lead => lead.status === 'cold').length
  const totalValue = leads.reduce((sum, lead) => sum + lead.budget, 0)

  const kpis = [
    {
      label: 'Hot',
      value: hotLeads,
      icon: FireIcon,
      color: 'text-red-400 bg-red-500/10 border-red-500/20',
      change: '+12%'
    },
    {
      label: 'Warm',
      value: warmLeads,
      icon: SunIcon,
      color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
      change: '+8%'
    },
    {
      label: 'Cold',
      value: coldLeads,
      icon: SparklesIcon,
      color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
      change: '-3%'
    },
    {
      label: 'Valor total',
      value: `${(totalValue / 1000).toFixed(0)}K€`,
      icon: CurrencyEuroIcon,
      color: 'text-green-400 bg-green-500/10 border-green-500/20',
      change: '+15%'
    }
  ]

  return (
    <motion.div
      className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2, duration: 0.5 }}
    >
      {kpis.map((kpi, index) => {
        const Icon = kpi.icon

        return (
          <motion.div
            key={kpi.label}
            className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-xl p-4 hover:bg-gray-800/50 transition-colors"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index, duration: 0.3 }}
            whileHover={{ y: -2 }}
          >
            <div className="flex items-center justify-between mb-3">
              <div className={`p-2 rounded-lg ${kpi.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <span className={`text-xs font-medium ${
                kpi.change.startsWith('+') ? 'text-green-400' : 'text-red-400'
              }`}>
                {kpi.change}
              </span>
            </div>

            <div>
              <div className="text-2xl font-bold text-white mb-1">
                {kpi.value}
              </div>
              <div className="text-sm text-gray-400">
                {kpi.label}
              </div>
            </div>
          </motion.div>
        )
      })}
    </motion.div>
  )
}