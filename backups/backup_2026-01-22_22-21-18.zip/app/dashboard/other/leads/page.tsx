"use client"

import { useState } from "react"
import { DashboardContainer } from "@/components/layout/DashboardContainer"
import { LeadsHeader } from "./components/LeadsHeader"
import { LeadsKPIs } from "./components/LeadsKPIs"
import { LeadsTable } from "./components/LeadsTable"
import { LeadsDetailPanel } from "./components/LeadsDetailPanel"
import { LeadsFiltersModal } from "./components/LeadsFiltersModal"
import { LeadsEmptyState } from "./components/LeadsEmptyState"
import { LEADS, LeadItem } from "./components/mock"

export default function LeadsPage() {
  const [selectedLead, setSelectedLead] = useState<LeadItem | null>(null)
  const [showFilters, setShowFilters] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [showDetailPanel, setShowDetailPanel] = useState(false)

  // Filter leads based on search and status
  const filteredLeads = LEADS.filter(lead => {
    const matchesSearch = lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || lead.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleLeadClick = (lead: LeadItem) => {
    setSelectedLead(lead)
    setShowDetailPanel(true)
  }

  const handleCloseDetailPanel = () => {
    setShowDetailPanel(false)
    setSelectedLead(null)
  }

  return (
    <DashboardContainer>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-white">Leads</h1>
        <p className="text-sm text-white/60">
          Gestiona y convierte contactos en oportunidades
        </p>
      </div>

      {/* Header with actions */}
      <LeadsHeader
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onNewLead={() => console.log("New lead")}
        onFilters={() => setShowFilters(true)}
      />

      {/* Compact KPIs */}
      <LeadsKPIs leads={LEADS} />

      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main table */}
        <div className={`${showDetailPanel ? 'lg:col-span-2' : 'lg:col-span-4'}`}>
          {filteredLeads.length > 0 ? (
            <LeadsTable
              leads={filteredLeads}
              onLeadClick={handleLeadClick}
              selectedLeadId={selectedLead?.id || null}
            />
          ) : (
            <LeadsEmptyState onCreateLead={() => console.log("Create lead")} />
          )}
        </div>

        {/* Detail panel */}
        {showDetailPanel && selectedLead && (
          <div className="lg:col-span-2">
            <LeadsDetailPanel
              lead={selectedLead}
              onClose={handleCloseDetailPanel}
            />
          </div>
        )}
      </div>

      {/* Filters modal */}
      <LeadsFiltersModal
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
      />
    </DashboardContainer>
  )
}