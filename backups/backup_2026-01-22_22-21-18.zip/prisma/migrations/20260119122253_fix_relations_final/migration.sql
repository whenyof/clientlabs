-- DropIndex
DROP INDEX "Account_userId_idx";
