import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting database seeding...')

  // Create default pipeline stages for all users
  // Note: In a real app, you'd create these for each user when they sign up
  // For now, we'll create them for a demo user

  const demoUserId = 'demo-user-id' // Replace with actual user ID

  console.log('Creating pipeline stages...')

  const stages = [
    {
      name: 'New',
      order: 0,
      color: '#6366f1',
    },
    {
      name: 'Contacted',
      order: 1,
      color: '#f59e0b',
    },
    {
      name: 'Qualified',
      order: 2,
      color: '#10b981',
    },
    {
      name: 'Proposal',
      order: 3,
      color: '#8b5cf6',
    },
    {
      name: 'Closed',
      order: 4,
      color: '#ef4444',
    }
  ]

  for (const stage of stages) {
    await prisma.pipelineStage.upsert({
      where: {
        userId_order: {
          userId: demoUserId,
          order: stage.order
        }
      },
      update: {},
      create: {
        userId: demoUserId,
        ...stage
      }
    })
  }

  console.log('✅ Pipeline stages created successfully')
  console.log('🎉 Database seeding completed!')
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })