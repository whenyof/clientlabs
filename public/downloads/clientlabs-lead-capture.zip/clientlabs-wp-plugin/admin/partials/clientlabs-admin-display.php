<?php
defined( 'ABSPATH' ) || exit;

$clientlabs_api_key      = get_option( 'clientlabs_api_key', '' );
$clientlabs_is_connected = ! empty( $clientlabs_api_key );
?>
<div class="wrap clientlabs-wrap" id="clientlabs-settings">

	<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

	<?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check for admin notice display after redirect.
	if ( isset( $_GET['updated'] ) && 'true' === sanitize_text_field( wp_unslash( $_GET['updated'] ) ) ) : ?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Configuración guardada correctamente.', 'clientlabs-lead-capture' ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( $clientlabs_is_connected ) : ?>
		<span class="clientlabs-status connected">&#9679; <?php esc_html_e( 'Conectado', 'clientlabs-lead-capture' ); ?></span>
	<?php else : ?>
		<span class="clientlabs-status disconnected">&#9679; <?php esc_html_e( 'Sin configurar', 'clientlabs-lead-capture' ); ?></span>
	<?php endif; ?>

	<form method="post" action="">
		<?php wp_nonce_field( 'clientlabs_save_settings', 'clientlabs_nonce' ); ?>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">
					<label for="clientlabs_api_key"><?php esc_html_e( 'Tu API Key', 'clientlabs-lead-capture' ); ?></label>
				</th>
				<td>
					<input
						type="text"
						id="clientlabs_api_key"
						name="clientlabs_api_key"
						value="<?php echo esc_attr( $clientlabs_api_key ); ?>"
						placeholder="cl_pub_..."
						class="regular-text"
					/>
					<p class="description">
						<?php esc_html_e( 'Encuentra tu API Key en tu panel de ClientLabs:', 'clientlabs-lead-capture' ); ?>
						<a href="https://clientlabs.io/dashboard/settings/api" target="_blank" rel="noopener noreferrer">
							clientlabs.io/dashboard/settings/api
						</a>
					</p>
				</td>
			</tr>
		</table>

		<?php submit_button( __( 'Guardar configuración', 'clientlabs-lead-capture' ) ); ?>
	</form>

	<div class="clientlabs-notice">
		<p>
			<?php esc_html_e( 'Este plugin se conecta al servicio externo ClientLabs (clientlabs.io) para registrar visitantes y leads de tu web. Al activarlo aceptas los', 'clientlabs-lead-capture' ); ?>
			<a href="https://clientlabs.io/terms" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'Términos de Servicio', 'clientlabs-lead-capture' ); ?>
			</a>
			<?php esc_html_e( 'y la', 'clientlabs-lead-capture' ); ?>
			<a href="https://clientlabs.io/privacy" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'Política de Privacidad', 'clientlabs-lead-capture' ); ?>
			</a>
			<?php esc_html_e( 'de ClientLabs.', 'clientlabs-lead-capture' ); ?>
		</p>
	</div>

</div>
