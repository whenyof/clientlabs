<?php
/**
 * Plugin Name: ClientLabs — Lead Capture
 * Plugin URI: https://clientlabs.io/wordpress-plugin
 * Description: Conecta tu web WordPress con ClientLabs para captar y gestionar leads automáticamente desde tu web.
 * Version: 1.0.0
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Author: ClientLabs
 * Author URI: https://clientlabs.io
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: clientlabs-lead-capture
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'CLIENTLABS_VERSION', '1.0.0' );
define( 'CLIENTLABS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CLIENTLABS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

require_once CLIENTLABS_PLUGIN_PATH . 'includes/class-clientlabs-activator.php';
require_once CLIENTLABS_PLUGIN_PATH . 'includes/class-clientlabs-admin.php';
require_once CLIENTLABS_PLUGIN_PATH . 'includes/class-clientlabs-tracker.php';

register_activation_hook( __FILE__, array( 'ClientLabs_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ClientLabs_Activator', 'deactivate' ) );

new ClientLabs_Admin();
new ClientLabs_Tracker();
