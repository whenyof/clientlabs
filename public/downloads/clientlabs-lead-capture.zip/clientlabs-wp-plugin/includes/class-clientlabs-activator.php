<?php
defined( 'ABSPATH' ) || exit;

class ClientLabs_Activator {

	public static function activate() {
		if ( ! get_option( 'clientlabs_api_key' ) ) {
			add_option( 'clientlabs_api_key', '' );
		}
	}

	public static function deactivate() {
		// Intentionally empty — preserve user data on deactivation.
	}
}
