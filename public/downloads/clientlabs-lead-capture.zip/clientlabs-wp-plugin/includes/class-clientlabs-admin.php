<?php
defined( 'ABSPATH' ) || exit;

class ClientLabs_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
		add_action( 'admin_init', array( $this, 'options_update' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	public function add_plugin_page() {
		add_options_page(
			__( 'ClientLabs', 'clientlabs-lead-capture' ),
			__( 'ClientLabs', 'clientlabs-lead-capture' ),
			'manage_options',
			'clientlabs',
			array( $this, 'display_plugin_setup_page' )
		);
	}

	public function display_plugin_setup_page() {
		include_once CLIENTLABS_PLUGIN_PATH . 'admin/partials/clientlabs-admin-display.php';
	}

	public function options_update() {
		if ( ! isset( $_POST['clientlabs_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['clientlabs_nonce'] ) ), 'clientlabs_save_settings' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'clientlabs-lead-capture' ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'clientlabs-lead-capture' ) );
		}

		$api_key = sanitize_text_field( wp_unslash( $_POST['clientlabs_api_key'] ?? '' ) );
		update_option( 'clientlabs_api_key', $api_key );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => 'clientlabs',
					'updated' => 'true',
				),
				admin_url( 'options-general.php' )
			)
		);
		exit;
	}

	public function enqueue_styles( $hook ) {
		if ( 'settings_page_clientlabs' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'clientlabs-admin',
			CLIENTLABS_PLUGIN_URL . 'admin/css/clientlabs-admin.css',
			array(),
			CLIENTLABS_VERSION
		);
	}
}
