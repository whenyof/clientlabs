<?php
defined( 'ABSPATH' ) || exit;

class ClientLabs_Tracker {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_tracking_script' ) );
	}

	public function enqueue_tracking_script() {
		if ( is_admin() ) return;

		$api_key = get_option( 'clientlabs_api_key', '' );
		if ( empty( $api_key ) ) return;

		wp_enqueue_script(
			'clientlabs-loader',
			'https://clientlabs.io/v1/loader.js',
			array(),
			CLIENTLABS_VERSION,
			false
		);

		wp_add_inline_script(
			'clientlabs-loader',
			'window.clientlabsConfig = {"key": "' . esc_js( $api_key ) . '"};',
			'before'
		);
	}
}
