=== ClientLabs — Lead Capture ===
Contributors: clientlabs
Tags: leads, crm, lead capture, marketing, analytics
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Capture and manage leads automatically from your WordPress website with ClientLabs.

== Description ==

ClientLabs is a lead capture and CRM platform for freelancers and small businesses. This plugin connects your WordPress website to your ClientLabs dashboard to automatically capture visitors and leads from your site.

= Features =
* Setup in 2 minutes, no coding required
* Automatic lead capture from forms
* Compatible with Contact Form 7, Elementor Forms and any standard HTML form
* Lead management dashboard at clientlabs.io
* No performance impact (async loading)

= External Service =
This plugin uses the ClientLabs service (https://clientlabs.io) to process and store lead capture data. By using this plugin, visitor data from your website is sent to ClientLabs servers.

* Website: https://clientlabs.io
* Privacy Policy: https://clientlabs.io/privacy
* Terms of Service: https://clientlabs.io/terms

== Installation ==

1. Upload the plugin to /wp-content/plugins/ or install it from the WordPress admin panel under Plugins → Add New → Upload Plugin
2. Activate the plugin under Plugins
3. Go to Settings → ClientLabs
4. Enter your API Key — find it at clientlabs.io/dashboard/settings/api
5. Save — your site is now connected

== Frequently Asked Questions ==

= Where do I find my API Key? =
In your ClientLabs dashboard, go to Settings → API Keys and copy your public key (starts with cl_pub_).

= Does the plugin affect performance? =
No. The script loads asynchronously so it does not block your page from loading.

= What data does it collect? =
Page visits, form submissions and lead identification data (email when a visitor fills out a form on your site).

= Is it compatible with my theme? =
Yes. The plugin is compatible with any WordPress theme as it only adds a script to the head of your site.

== Changelog ==

= 1.0.0 =
* Initial stable release

== Upgrade Notice ==

= 1.0.0 =
First stable release.
