<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'clientlabs_api_key' );
