import AuthShell from "@/components/auth/AuthShell"

export default function Page() {
  return <AuthShell />
}