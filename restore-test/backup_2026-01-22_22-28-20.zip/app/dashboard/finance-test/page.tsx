"use client"

export default function FinanceTestPage() {
  return (
    <div>
      <h1>Finance Test Page</h1>
      <p>This is a test page in a different location.</p>
    </div>
  )
}
