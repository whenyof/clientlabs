"use client"

import { motion } from "framer-motion"
import { LeadItem } from "./mock"
import {
  XMarkIcon,
  EnvelopeIcon,
  PhoneIcon,
  ClockIcon,
  CurrencyEuroIcon,
  BuildingOfficeIcon,
  UserIcon,
  FireIcon,
  SunIcon,
  SparklesIcon,
  CheckCircleIcon,
  XCircleIcon
} from "@heroicons/react/24/outline"

interface LeadsDetailPanelProps {
  lead: LeadItem
  onClose: () => void
}

export function LeadsDetailPanel({ lead, onClose }: LeadsDetailPanelProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'hot':
        return <FireIcon className="w-5 h-5 text-red-400" />
      case 'warm':
        return <SunIcon className="w-5 h-5 text-yellow-400" />
      case 'cold':
        return <SparklesIcon className="w-5 h-5 text-blue-400" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'hot':
        return 'bg-red-500/20 text-red-400 border-red-500/20'
      case 'warm':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20'
      case 'cold':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/20'
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/20'
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(amount)
  }

  const quickActions = [
    {
      label: 'Enviar email',
      icon: EnvelopeIcon,
      action: () => console.log('Send email to', lead.email),
      color: 'text-blue-400 hover:bg-blue-500/10'
    },
    {
      label: 'Llamar',
      icon: PhoneIcon,
      action: () => console.log('Call', lead.phone),
      color: 'text-green-400 hover:bg-green-500/10'
    },
    {
      label: 'Programar seguimiento',
      icon: ClockIcon,
      action: () => console.log('Schedule follow-up for', lead.name),
      color: 'text-purple-400 hover:bg-purple-500/10'
    }
  ]

  const statusOptions = [
    { value: 'hot', label: 'Hot', icon: FireIcon, color: 'text-red-400' },
    { value: 'warm', label: 'Warm', icon: SunIcon, color: 'text-yellow-400' },
    { value: 'cold', label: 'Cold', icon: SparklesIcon, color: 'text-blue-400' }
  ]

  return (
    <motion.div
      className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-2xl p-6 h-fit sticky top-6"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">Detalles del lead</h3>
        <button
          onClick={onClose}
          className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-colors"
        >
          <XMarkIcon className="w-4 h-4" />
        </button>
      </div>

      {/* Lead info */}
      <div className="space-y-6">
        {/* Avatar and basic info */}
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-3">
            {lead.name.charAt(0)}
          </div>
          <h4 className="text-xl font-semibold text-white mb-1">{lead.name}</h4>
          <p className="text-gray-400">{lead.company}</p>
        </div>

        {/* Status */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">Estado</label>
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border ${getStatusColor(lead.status)}`}>
            {getStatusIcon(lead.status)}
            <span className="font-medium capitalize">{lead.status}</span>
          </div>

          {/* Status options */}
          <div className="grid grid-cols-3 gap-2 mt-3">
            {statusOptions.map(option => {
              const Icon = option.icon
              const isSelected = lead.status === option.value

              return (
                <motion.button
                  key={option.value}
                  className={`flex items-center justify-center gap-2 p-2 rounded-lg border transition-colors ${
                    isSelected
                      ? `${getStatusColor(option.value)} border-opacity-50`
                      : 'border-gray-600 hover:border-gray-500 text-gray-400 hover:text-white'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? option.color : ''}`} />
                  <span className="text-xs">{option.label}</span>
                </motion.button>
              )
            })}
          </div>
        </div>

        {/* Contact details */}
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
            <EnvelopeIcon className="w-4 h-4 text-gray-400" />
            <span className="text-white">{lead.email}</span>
          </div>
          <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
            <PhoneIcon className="w-4 h-4 text-gray-400" />
            <span className="text-white">{lead.phone}</span>
          </div>
          <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
            <BuildingOfficeIcon className="w-4 h-4 text-gray-400" />
            <span className="text-white">{lead.company}</span>
          </div>
          <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
            <UserIcon className="w-4 h-4 text-gray-400" />
            <span className="text-white">{lead.owner}</span>
          </div>
        </div>

        {/* Budget */}
        <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <CurrencyEuroIcon className="w-4 h-4 text-green-400" />
            <span className="text-green-400 font-medium">Presupuesto</span>
          </div>
          <div className="text-2xl font-bold text-white">{formatCurrency(lead.budget)}</div>
        </div>

        {/* Quick actions */}
        <div>
          <h5 className="text-sm font-medium text-gray-400 mb-3">Acciones rápidas</h5>
          <div className="space-y-2">
            {quickActions.map(action => {
              const Icon = action.icon
              return (
                <motion.button
                  key={action.label}
                  onClick={action.action}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border border-gray-600 hover:border-gray-500 transition-colors ${action.color}`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{action.label}</span>
                </motion.button>
              )
            })}
          </div>
        </div>

        {/* Conversion actions */}
        <div className="space-y-2">
          <motion.button
            className="w-full flex items-center justify-center gap-2 p-3 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <CheckCircleIcon className="w-4 h-4" />
            Marcar como ganado
          </motion.button>

          <motion.button
            className="w-full flex items-center justify-center gap-2 p-3 bg-red-600/20 hover:bg-red-600/30 text-red-400 hover:text-red-300 rounded-lg border border-red-500/20 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <XCircleIcon className="w-4 h-4" />
            Marcar como perdido
          </motion.button>
        </div>

        {/* Last contact */}
        <div className="pt-4 border-t border-gray-700/50">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <ClockIcon className="w-4 h-4" />
            <span>Último contacto: {lead.lastContact}</span>
          </div>
        </div>
      </div>
    </motion.div>
  )
}