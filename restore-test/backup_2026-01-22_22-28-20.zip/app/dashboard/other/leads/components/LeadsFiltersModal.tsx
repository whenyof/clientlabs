"use client"

import { motion, AnimatePresence } from "framer-motion"
import { XMarkIcon } from "@heroicons/react/24/outline"

interface LeadsFiltersModalProps {
  isOpen: boolean
  onClose: () => void
  statusFilter: string
  onStatusFilterChange: (value: string) => void
}

export function LeadsFiltersModal({
  isOpen,
  onClose,
  statusFilter,
  onStatusFilterChange
}: LeadsFiltersModalProps) {
  const statusOptions = [
    { value: 'all', label: 'Todos los estados' },
    { value: 'hot', label: 'Hot' },
    { value: 'warm', label: 'Warm' },
    { value: 'cold', label: 'Cold' }
  ]

  const handleStatusChange = (value: string) => {
    onStatusFilterChange(value)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gray-900 rounded-2xl border border-gray-700 shadow-2xl z-50 w-full max-w-md"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Filtros</h3>
                <button
                  onClick={onClose}
                  className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Status filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-3">
                    Estado del lead
                  </label>
                  <div className="space-y-2">
                    {statusOptions.map(option => (
                      <motion.button
                        key={option.value}
                        onClick={() => handleStatusChange(option.value)}
                        className={`w-full text-left px-4 py-3 rounded-lg border transition-colors ${
                          statusFilter === option.value
                            ? 'bg-purple-600/20 border-purple-500/50 text-purple-400'
                            : 'bg-gray-800/50 border-gray-700/50 text-gray-300 hover:bg-gray-700/50 hover:border-gray-600'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        {option.label}
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Date range (placeholder for future) */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-3">
                    Rango de fechas
                  </label>
                  <div className="space-y-2">
                    <button className="w-full text-left px-4 py-3 bg-gray-800/50 border border-gray-700/50 rounded-lg text-gray-500 cursor-not-allowed">
                      Próximamente
                    </button>
                  </div>
                </div>

                {/* Owner filter (placeholder for future) */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-3">
                    Responsable
                  </label>
                  <div className="space-y-2">
                    <button className="w-full text-left px-4 py-3 bg-gray-800/50 border border-gray-700/50 rounded-lg text-gray-500 cursor-not-allowed">
                      Próximamente
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-8">
                <button
                  onClick={() => {
                    onStatusFilterChange('all')
                    onClose()
                  }}
                  className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
                >
                  Limpiar filtros
                </button>
                <button
                  onClick={onClose}
                  className="flex-1 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                >
                  Aplicar
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}