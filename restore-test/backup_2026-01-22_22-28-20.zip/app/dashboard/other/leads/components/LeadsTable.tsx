"use client"

import { motion } from "framer-motion"
import { LeadItem } from "./mock"
import {
  EyeIcon,
  FireIcon,
  SunIcon,
  SparklesIcon,
  CurrencyEuroIcon
} from "@heroicons/react/24/outline"

interface LeadsTableProps {
  leads: LeadItem[]
  onLeadClick: (lead: LeadItem) => void
  selectedLeadId: string | null
}

export function LeadsTable({ leads, onLeadClick, selectedLeadId }: LeadsTableProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'hot':
        return <FireIcon className="w-4 h-4 text-red-400" />
      case 'warm':
        return <SunIcon className="w-4 h-4 text-yellow-400" />
      case 'cold':
        return <SparklesIcon className="w-4 h-4 text-blue-400" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'hot':
        return 'bg-red-500/20 text-red-400 border-red-500/30'
      case 'warm':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
      case 'cold':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30'
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30'
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(amount)
  }

  return (
    <motion.div
      className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-2xl overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.5 }}
    >
      {/* Table header */}
      <div className="grid grid-cols-12 gap-4 p-6 border-b border-gray-700/30 bg-gray-800/50">
        <div className="col-span-4 text-sm font-semibold text-gray-300">Cliente</div>
        <div className="col-span-2 text-sm font-semibold text-gray-300">Estado</div>
        <div className="col-span-2 text-sm font-semibold text-gray-300">Valor</div>
        <div className="col-span-3 text-sm font-semibold text-gray-300">Último contacto</div>
        <div className="col-span-1 text-sm font-semibold text-gray-300">Acción</div>
      </div>

      {/* Table rows */}
      <div className="divide-y divide-gray-700/20">
        {leads.map((lead, index) => (
          <motion.div
            key={lead.id}
            className={`grid grid-cols-12 gap-4 p-6 hover:bg-gray-700/20 transition-colors cursor-pointer ${
              selectedLeadId === lead.id ? 'bg-purple-500/10 border-l-4 border-purple-500' : ''
            }`}
            onClick={() => onLeadClick(lead)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index, duration: 0.3 }}
            whileHover={{ backgroundColor: 'rgba(55, 65, 81, 0.3)' }}
          >
            {/* Client */}
            <div className="col-span-4 flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                {lead.name.charAt(0)}
              </div>
              <div>
                <div className="text-white font-medium">{lead.name}</div>
                <div className="text-sm text-gray-400">{lead.company}</div>
              </div>
            </div>

            {/* Status */}
            <div className="col-span-2 flex items-center">
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(lead.status)}`}>
                {getStatusIcon(lead.status)}
                <span className="capitalize">{lead.status}</span>
              </div>
            </div>

            {/* Value */}
            <div className="col-span-2 flex items-center">
              <div className="flex items-center gap-1">
                <CurrencyEuroIcon className="w-4 h-4 text-green-400" />
                <span className="text-white font-medium">
                  {formatCurrency(lead.budget)}
                </span>
              </div>
            </div>

            {/* Last contact */}
            <div className="col-span-3 flex items-center">
              <span className="text-gray-400 text-sm">{lead.lastContact}</span>
            </div>

            {/* Action */}
            <div className="col-span-1 flex items-center">
              <motion.button
                className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => {
                  e.stopPropagation()
                  onLeadClick(lead)
                }}
              >
                <EyeIcon className="w-4 h-4" />
              </motion.button>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}